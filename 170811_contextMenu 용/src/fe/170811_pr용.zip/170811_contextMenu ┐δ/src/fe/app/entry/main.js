
import FileListController from "controller/FileListController.js"
import "css/custom.css"
import "css/non-responsive-bootstrap.css"

$(document).ready(function(){
	let fileController = new FileListController();	
})

